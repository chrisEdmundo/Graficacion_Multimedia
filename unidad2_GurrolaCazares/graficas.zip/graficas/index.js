$(document).ready(function(){
    var ctx= document.getElementById("myChart");
    var myChart = new Chart(ctx,{
        type:'bar',
        data:{
            labels:[" 10 - 17","18 -24  ","25 - 40 "],
            datasets:[{
                label:'Numero de lectores por edad',
                data:[229,800,720],
                backgroundColor:["red","black","green"]
            }]
        }
    });
    
    var lineas=document.getElementById("myChartlinas");
    var myChart = new Chart(lineas,{
        type:'line',
        data:{
            labels:["Comedia","Misterio","Horror","Novelas","ficcion","Conocimiento"],
            datasets:[{
                label:'Genros mas leidos',
            data:[520,328,274,365,687,964],
            fill:true,
            borderColor:'rgb(55,225,680)',
            backgroundColor: 'rgba(55,225,68, 0.75)',
            lineTension: 0.8,
            pointBackgroundColor:('yellow')
        }]
        }
    });
    var radar = document.getElementById("myChartRadar");
    var myChart = new Chart(radar,{
        type:'radar',
        data:{
            labels:["Pasar el tiempo","Escuela","les gusta","Interes"],
            datasets:[{
                label:'Motivos de lectura',
            data:[250,328,850,400],
            
            backgroundColor: 'rgba(55,225,68, 0.75)',
            lineTension: 0.5,
            pointBackgroundColor:('yellow')
        },
        {
                label:'Personas que comparn libros',
            data:[400,642,700,154],
            
            backgroundColor: 'rgba(55,225,68, 0.75)',
            lineTension: 0.5,
            pointBackgroundColor:('yellow')
        }]
                            
        }
        
        
    });
    
    var pie = document.getElementById("myChartpie");
    var myChart = new Chart(pie,{
        type: 'pie',
        data: {
             labels:["Escuela","Playa","Casa","Lugares abiertos","Transporte"],
            datasets:[{
                label:'# de seguidores',
            data:[200,328,989,365,500],
            
            backgroundColor:[
            'rgba(55,225,68, 0.75)',
            'rgba(48,66,161, 0.75)',
            'rgba(243,225,68, 0.75)',
            'rgba(224,184,128, 0.75)',
            'rgba(120,225,243, 0.75)',
            'rgba(243,242,120, 0.75)',
            
            ],
            lineTension: 0.5,
            pointBackgroundColor:('rgba(255,100,55, 0.85)'),
            
        }]
    }
                            
    });
    
    var polar= document.getElementById("myChartPolar");
    var myChart = new Chart(polar,{
        
       type: 'polarArea',
        data: {
             labels:["-1","1","+1","5","+5"],
            datasets:[{
                label:'Horas delectura',
            data:[520,328,274,365,687],
            
            backgroundColor:[
            'rgba(55,225,68, 0.75)',
            'rgba(48,66,161, 0.75)',
            'rgba(243,225,68, 0.75)',
            'rgba(224,184,128, 0.75)',
            'rgba(120,225,243, 0.75)',
            'rgba(243,242,120, 0.75)',
            
            ],
            lineTension: 0.5,
            pointBackgroundColor:('rgba(255,100,55, 0.85)'),
            
        }]
    }
        
    });
    
    
    var dona= document.getElementById("myChartDona");
    var myChart = new Chart(dona,{
        
                type: 'doughnut',
        data: {
             labels:["Estudiantes","Amas de casa","Profecionistas","Indistinto"],
            datasets:[{
                label:'# de seguidores',
            data:[520,328,274,365],
            
            backgroundColor:[
            'rgba(55,225,68, 0.75)',
            'rgba(48,66,161, 0.75)',
            'rgba(243,225,68, 0.75)',
            'rgba(224,184,128, 0.75)',
            'rgba(120,225,243, 0.75)',
            'rgba(243,242,120, 0.75)',
            
            ],
            borderColor:[
            'rgba(55,225,68, 0.75)',
            'rgba(48,66,161, 0.75)',
            'rgba(243,225,68, 0.75)',
            'rgba(224,184,128, 0.75)',
            'rgba(120,225,243, 0.75)',
            'rgba(243,242,120, 0.75)',
            ]
           ,
            borderWidth:[
            
            'rgba(55,225,68, 0.75)',
            'rgba(48,66,161, 0.75)',
            'rgba(243,225,68, 0.75)',
            'rgba(224,184,128, 0.75)',
            'rgba(120,225,243, 0.75)',
            'rgba(243,242,120, 0.75)',
            ]
            
        }]
    }
        
    });
    
        var bubble= document.getElementById("myChartBubble");
        var myChart = new Chart(bubble,{

           type: 'bubble',
            data: {
            datasets:[{
                label:'Libros que se compran en un mes deacuerdo a su edad',
                data:[{"x":18,"y":4,"r":15},{"x":25,"y":8,"r":12},{"x":38,"y":3,"r":10}],

                backgroundColor:[ 'rgba(48,66,161, 0.75)','rgba(243,242,120, 0.75)', 'rgba(55,225,68, 0.75)'],
              
            }]
        }
        
    });
    
                            
      
        
});